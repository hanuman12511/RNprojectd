import React from 'react';
import 'react-native-gesture-handler';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import colors from './src/consts/colors';
import{StatusBar} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import OnBoardScreen from './src/view/screens/OnBoardScreen';
import DetailsScreen from './src/view/screens/DetailsScreen';
import BottomNavigator from './src/view/navigations/BottomNavigator';
const Stack = createStackNavigator();

const App = () =>{
  return(
    <NavigationContainer>
        <StatusBar backgroundColor={colors.white} barStyle="dark-content" />
        <Stack.Navigator screenOptions={{headerShown:false}}>
          <Stack.Screen name='BoardScreen' component={OnBoardScreen} />
          <Stack.Screen name='Home' component={BottomNavigator} />
          <Stack.Screen name='DetailsScreen' component={DetailsScreen} />
        
        </Stack.Navigator>
    </NavigationContainer>
  );
};
export default App;