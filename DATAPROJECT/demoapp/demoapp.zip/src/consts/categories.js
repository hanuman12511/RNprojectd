const categories = [
    {id:'1',name:'pizza',image:require('../asserts/img1.jpg')},
    {id:'2',name:'Burger',image:require('../asserts/img2.jpg')},
    {id:'3',name:'Sushi',image:require('../asserts/img3.jpg')},
    {id:'4',name:'salad',image:require('../asserts/img6.jpg')},
];
export default categories;