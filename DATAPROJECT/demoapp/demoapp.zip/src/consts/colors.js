const colors = {

    white:'#FFF',
    dark :'#000',
    primary:'#f9813a',
    secondary:'#fedac5',
    light:'#e5e5e5',
    grey:'#908e8c'
};
export default colors;