const foods = [
    {id:'1',name:'Cheese pizza',desc:'Cheese pizza',price:'7.10',image:require('../asserts/img1.jpg')},
    {id:'2',name:'Chicken Burger',desc:'Chicken Burger',price:'8.55',image:require('../asserts/img2.jpg')},
    {id:'3',name:'Sushi Makizushi',desc:'Sushi Makizushi',price:'9.34',image:require('../asserts/img3.jpg')},
    {id:'4',name:'salad',desc:'salad meat',price:'5.45',image:require('../asserts/img6.jpg')},
];
export default foods;