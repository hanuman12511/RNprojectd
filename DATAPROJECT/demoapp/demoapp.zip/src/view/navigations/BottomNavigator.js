import React from 'react';
import 'react-native-gesture-handler';
import Icon from 'react-native-vector-icons/FontAwesome';

import colors from '../../consts/colors';
import{View} from 'react-native';
import HomeScreen from '../screens/HomeScreen';
import DetailsScreen from '../screens/DetailsScreen';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';


const Tab = createBottomTabNavigator();
const BottomNavigator = () =>{

    return <Tab.Navigator>
        <Tab.Screen name='HomeScreen'
         component={HomeScreen} 
         options={{
            tabBarLabel: 'Home',
             tabBarIcon: ({ color, size }) => (
               <Icon
                   name="home"
                   color={color}
                   size={size}
                 />
             ),
          }} />
         <Tab.Screen name='DetailsScreen'
         component={DetailsScreen} 
         options={{
            tabBarLabel: 'Setting',
             tabBarIcon: ({ color, size }) => (
               <Icon
                   name="abacus"
                   color={color}
                   size={size}
                 />
             ),
          }} />
    </Tab.Navigator>;
};
export default BottomNavigator;