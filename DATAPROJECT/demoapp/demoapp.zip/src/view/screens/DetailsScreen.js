import React from 'react';
import {View,Text,SafeAreaView} from 'react-native';

export default DetailsScreen = () =>{

return(
    <SafeAreaView>
        <View>
            <Text>
            DetailsScreen
            </Text>
        </View>
    </SafeAreaView>
);

}