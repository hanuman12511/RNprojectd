import React from 'react';
import {View,Text,SafeAreaView} from 'react-native';
import { PrimaryButton } from '../components/Button';

export default HomeScreen   = () =>{

return(
    <SafeAreaView>
        <View>
            <Text>
            HomeScreen
            </Text>
        </View>
    </SafeAreaView>
);

}