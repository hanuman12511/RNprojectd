import React from 'react';
import {View,Text,SafeAreaView} from 'react-native';
import { PrimaryButton } from '../components/Button';

export default OnBoardScreen = ({navigation}) =>{

   
return(
    <SafeAreaView>
        <View>
            <Text>
            OnBoardScreen
            </Text>
            
            <PrimaryButton title="get started"   onPress={()=>navigation.navigate('Home')}/>
        </View>
    </SafeAreaView>
);

}